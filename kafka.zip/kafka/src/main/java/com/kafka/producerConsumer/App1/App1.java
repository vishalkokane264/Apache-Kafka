package com.kafka.producerConsumer.App1;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.ForeachAction;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;

import com.google.common.base.Splitter;
import com.kafka.producerConsumer.IKafkaConstants.IKafkaConstants;
import com.kafka.producerConsumer.KStreamBuilder.KStreamBuilder;
import com.kafka.producerConsumer.createConsumer.ConsumerCreator;
import com.kafka.producerConsumer.producerCreator.producerCreator;
import com.sun.net.httpserver.Filter;

public class App1 {
	  static final String topicName = "inputTopic";
    public static void main(String[] args) throws Exception
    {
    	String file1="/Users/vishalkokane/emp.txt";
    	String file2="/Users/vishalkokane/dept.txt";
		Consumer<Long, String> consumer2 = ConsumerCreator.createConsumer("empdata");
		Consumer<Long, String> consumer3 = ConsumerCreator.createConsumer("deptdata");

		runProducer(file1,"empdata");
		runProducer(file2,"deptdata");
		load_data_in_ktable("empdata","deptdata");
		
//    	runConsumer(consumer2,"Output2.txt");    
//    	runConsumer(consumer3,"Output3.txt");
    }

	private static void load_data_in_ktable(String topic1,String topic2) throws InterruptedException {
		// TODO Auto-generated method stub
	    Properties prop = new Properties();
	    prop.put(StreamsConfig.APPLICATION_ID_CONFIG, "streams-pipe2");
	    prop.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
	    prop.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
	    prop.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
	    StreamsBuilder builder = new StreamsBuilder();
	    KStream<String, String> textLines = builder.stream(topic1);	 
	    KStream<String, String> textLines2 = builder.stream(topic2);

	    KStream<String, String>data2=textLines.filter((key,value)->value.contains(",")).selectKey((key,value)->value.split(",")[0].toLowerCase()).mapValues(value->value.split(",")[1].toLowerCase());
	    KStream<String, String>data3=textLines2.filter((key,value)->value.contains(",")).selectKey((key,value)->value.split(",")[0].toLowerCase()).mapValues(value->value.split(",")[1].toLowerCase());
//	    KStream<String, String> joined = data2.leftJoin(data3,
//	            (leftValue, rightValue) -> "left=" + leftValue + ", right=" + rightValue, /* ValueJoiner */
//	            JoinWindows.of(TimeUnit.MINUTES.toMillis(5)),
//	            Joined.with(
//	              Serdes.String(),
//	              Serdes.String()/* left value */
//	          );
	    data3.foreach(new ForeachAction<String,String>(){

			@Override
			public void apply(String key, String value) {
				// TODO Auto-generated method stub
				System.out.println(key+"---"+value);
			}
	    
	    });
	    		
	    		
	    KTable<String, Long> wordCounts = textLines
		        .flatMapValues(textLine1 -> Arrays.asList(textLine1.split(",")))
		        .groupBy((key,value)->value)
		        .count();
		        
//	    wordCounts.toStream().foreach(new ForeachAction<String,Long>(){
//			@Override
//			public void apply(String key, Long value) {
//				// TODO Auto-generated method stub
//				System.out.println("Emp:key "+key);
//			}		    
//	    });

	    
//	    KTable<String, Long> wordCounts2 = textLines2.selectKey((key,value)->value.split(",")[0]).groupByKey().count();
//		    wordCounts2.toStream().foreach(new ForeachAction<String,Long>(){
//				@Override
//				public void apply(String key, Long value) {
//					// TODO Auto-generated method stub
//					System.out.println("Dept:key "+key+" "+value);
//				}
//		    	
//		    });
		    
//	    KTable<String,String> wordCount3=wordCounts.leftJoin(wordCounts2,(key1,value1)->key1+"");
//	    wordCount3.toStream().foreach(new ForeachAction<String,String>(){
//			@Override
//			public void apply(String key, String value) {
//				// TODO Auto-generated method stub
//				System.out.println("Join: "+key);
//			}
//	    	
//	    });

	    System.out.println("Data over");
	    KafkaStreams streams = new KafkaStreams(builder.build(), prop);
	    streams.start();
	    Thread.sleep(5000);
	    streams.close();
	    return;
	}

	static void runConsumer(Consumer<Long, String> consumer,String file) throws IOException {

		int noMessageToFetch = 0;
		while (true) {
			final ConsumerRecords<Long, String> consumerRecords = consumer.poll(10);
			if (consumerRecords.count() == 0) {
				noMessageToFetch++;
				if (noMessageToFetch > IKafkaConstants.MAX_NO_MESSAGE_FOUND_COUNT)
					break;
				else
					continue;
			}
			consumerRecords.forEach(record -> {
				System.out.println(record.value());				
			});
			consumer.commitAsync();
		}
		consumer.close();
	}
    
	static void runProducer(String file1, String topicName) throws IOException {
		Producer<Long, String> producer = producerCreator.createProducer();
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = "\n";
        int index=0;
        try
        {
            br = new BufferedReader(new FileReader(file1));
            while ((line = br.readLine()) != null)
            {
            	index++;
//                String[] data = line.split(cvsSplitBy);
    			final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(topicName,line.toString());    			
    			try {
    				RecordMetadata metadata = producer.send(record).get();    				
    				System.out.println("Data send: "+record.value());
    				metadata.partition();
    				metadata.offset();
    	
    			} catch (ExecutionException e) {
    				System.out.println("Error in sending record");
    				System.out.println(e);
    			} catch (InterruptedException e) {
    				System.out.println("Error in sending record");
    				System.out.println(e);
    			}

            }

        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }

	}
}

//package com.kafka.producerConsumer.App1;
//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Properties;
//import java.util.concurrent.ExecutionException;
//import java.util.concurrent.TimeUnit;
//import java.util.regex.Pattern;
//
//import org.apache.kafka.clients.consumer.Consumer;
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.clients.consumer.ConsumerRecords;
//import org.apache.kafka.clients.producer.Producer;
//import org.apache.kafka.clients.producer.ProducerRecord;
//import org.apache.kafka.clients.producer.RecordMetadata;
//import org.apache.kafka.common.serialization.Serdes;
//import org.apache.kafka.streams.KafkaStreams;
//import org.apache.kafka.streams.StreamsBuilder;
//import org.apache.kafka.streams.StreamsConfig;
//import org.apache.kafka.streams.Topology;
//import org.apache.kafka.streams.kstream.Consumed;
//import org.apache.kafka.streams.kstream.ForeachAction;
//import org.apache.kafka.streams.kstream.JoinWindows;
//import org.apache.kafka.streams.kstream.Joined;
//import org.apache.kafka.streams.kstream.KStream;
//import org.apache.kafka.streams.kstream.KTable;
//import org.apache.kafka.streams.kstream.Printed;
//import org.apache.kafka.streams.kstream.Produced;
//
//import com.kafka.producerConsumer.IKafkaConstants.IKafkaConstants;
//import com.kafka.producerConsumer.KStreamBuilder.KStreamBuilder;
//
//import com.kafka.producerConsumer.createConsumer.ConsumerCreator;
//import com.kafka.producerConsumer.producerCreator.producerCreator;
//
//public class App1 {
//	  static final String topicName = "inputTopic";
//	  public static void main(final String[] args) throws Exception {
//		    Properties prop = new Properties();
//		    prop.put(StreamsConfig.APPLICATION_ID_CONFIG, "streams-pipe2");
//		    prop.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
//		    prop.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
//		    prop.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
//		    StreamsBuilder builder = new StreamsBuilder();
//		    
//		    KStream<String, String> textLines = builder.stream("inputTopic");
//		    KStream<String, String> textLines2=builder.stream("outputTopic1");
//		    
//		    KTable<String, Long> wordCounts = textLines
//		        .flatMapValues(textLine -> Arrays.asList(textLine.split(":")))
//		        .groupBy((key, word) -> word)
//		        .count();
//		    wordCounts.toStream().foreach(new ForeachAction<String,Long>(){
//				@Override
//				public void apply(String key, Long value) {
//					// TODO Auto-generated method stub
//					System.out.println("table1:key"+key+" value:"+value);
//				}
//		    	
//		    });
//
////		    KTable<String, Long> wordCounts2 = textLines2
////			        .flatMapValues(textLine -> Arrays.asList(textLine.split(":")))
////			        .groupBy((key, word) -> word)
////			        .count();
////		    wordCounts2.toStream().foreach(new ForeachAction<String,Long>(){
////				@Override
////				public void apply(String key, Long value) {
////					// TODO Auto-generated method stub
////					System.out.println("table2:key"+key+" value:"+value);
////				}
////		    	
////		    });
////		    KTable<String,String> wordCount3=wordCounts.leftJoin(wordCounts2,(key1,value1)->key1+" "+value1);
////		    wordCount3.toStream().foreach(new ForeachAction<String,String>(){
////				@Override
////				public void apply(String key, String value) {
////					// TODO Auto-generated method stub
////					System.out.println("Join"+key+" "+value);
////				}
////		    	
////		    });
//		    
////		    wordCounts.toStream().to("topicz");
//
//		    KafkaStreams streams = new KafkaStreams(builder.build(), prop);
//		    streams.start();
//		    Thread.sleep(5000);
//		    streams.close();
//		  }
//		}
package com.kafka.producerConsumer.ObjectMapper;
import com.kafka.producerConsumer.CustomObject.CustomObject;

public class ObjectMapper {

	public CustomObject readValue(byte[] data, Class<CustomObject> class1) {
		// TODO Auto-generated method stub
		return null;
	}

	public String writeValueAsString(CustomObject data) {
		// TODO Auto-generated method stub
		return null;
	}

	
}

package com.kafka.producerConsumer.KStreamBuilder;

import java.util.Properties;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;


public class KStreamBuilder {
	public KStreamBuilder()
	{		
	}

	public KStream<String, String> stream(String topic) {
		// TODO Auto-generated method stub
		return null;
	}
}


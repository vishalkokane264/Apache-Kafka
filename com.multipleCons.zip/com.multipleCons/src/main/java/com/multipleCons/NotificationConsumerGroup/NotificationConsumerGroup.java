package com.multipleCons.NotificationConsumerGroup;

import java.util.ArrayList;
import java.util.List;

import com.multipleCons.NotificationConsumerThread.NotificationConsumerThread;

public final class NotificationConsumerGroup {
	  private final int numberOfConsumers;
	  private final String groupId;
	  private final String topic;
	  private final String brokers;
	  private List<NotificationConsumerThread> consumers;
	  private List<NotificationConsumerThread> consumers2;

	  public NotificationConsumerGroup(String brokers, String groupId, String topic, int numberOfConsumers) {
	    this.brokers = brokers;
	    this.topic = topic;
	    this.groupId = groupId;
	    this.numberOfConsumers = numberOfConsumers;
	    consumers = new ArrayList<>();
	    for (int i = 0; i < this.numberOfConsumers; i++) {
	      NotificationConsumerThread ncThread =
	          new NotificationConsumerThread(this.brokers, this.groupId, this.topic);
	      consumers.add(ncThread);
	      System.out.println("consumer:"+i+" created");
	    }
	  }

	  public void execute() {
	    for (NotificationConsumerThread ncThread : consumers) {
	      Thread t = new Thread(ncThread);
	      t.start();
	    }
	  }

	  /**
	   * @return the numberOfConsumers
	   */
	  public int getNumberOfConsumers() {
	    return numberOfConsumers;
	  }

	  /**
	   * @return the groupId
	   */
	  public String getGroupId() {
	    return groupId;
	  }
	}